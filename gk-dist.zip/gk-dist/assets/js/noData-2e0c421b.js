const a="/assets/png/noData-fa28091f.png";export{a as n};
