import{d as J,bj as f,i as M,D as K,r as a,o as l,c as p,b as t,w as e,l as Q,u as d,e as n,F as _,f as g,a as s,t as u,g as D,p as X,h as Y,_ as Z}from"./index-cf10266c.js";import{M as ee}from"./EditorWorker.vue_vue_type_script_setup_true_lang-98458242.js";import{u as te}from"./useTargetData.hook-bce2a5da.js";import{i as oe}from"./icon-2ec39e0c.js";import"./axios-cda6f04c.js";import"./pick-84505e0b.js";import{n as ne}from"./useLifeHandler.hook-70dd9c59.js";import"./langStore-7bee2f5f.js";import"./chartEditStore-36d02915.js";import"./publicConfig-b562ca70.js";import"./index-512a6e87.js";import"./router-66113034.js";import"./index-d7795080.js";import"./install-0ac8a5ef.js";const ae=`
console.log(e)
`,se=`
console.log(echarts)
`,le=`
console.log(components)
`,ce=`
console.log(node_modules)
`,de=`
// 在渲染之后才能获取 dom 实例
e.el.addEventListener('click', () => {
  alert('我触发拉~');
}, false)
`,re=`
await import('https://lf3-cdn-tos.bytecdntp.com/cdn/expire-1-M/lodash.js/4.17.21/lodash.js')

// lodash 默认赋值给 "_"
console.log('isEqual', _.isEqual(['1'], ['1']))
`,ie=`
// 获取echart实例
const chart = this.refs.vChartRef.chart

// 图表设置tooltip
chart.setOption({
  tooltip: {
    trigger: 'axis', //item
    enterable: true, 
    formatter (params) {
      return\`
        <div>
          <img src="https://portrait.gitee.com/uploads/avatars/user/1654/4964818_MTrun_1653229420.png!avatar30">
          <b><a href="https://gitee.com/dromara/go-view">《这是一个自定义的tooltip》</a></b>
        <div>
        <div style='border-radius:35px;color:#666'>
        \${Object.entries(params[0].value).map(kv => \`<div>\${kv[0]}:\${kv[1]}</div>\`).join('')}
        </div>
      \`;
    },
  }
})
`,pe=`
// 组件样式作用域标识
const scoped = this.subTree.scopeId
function loadStyleString(css){
	let style = document.createElement('style')
	style.type = 'text/css'
	style.appendChild(document.createTextNode(css))
	let head = document.getElementsByTagName('head')[0]
	head.appendChild(style)
}
loadStyleString(\`
.dv-scroll-board[\${scoped}] {
  position: relative;
  overflow: hidden;
}
.dv-scroll-board[\${scoped}]::before {
  content: '';
  display: block;
  position: absolute;
  top: -20%;
  left: -100%;
  width: 550px;
  height: 60px;
  transform: rotate(-45deg);
  background-image: linear-gradient(rgba(0, 0, 0, 0), rgba(255, 255, 255, 0.3), rgba(0, 0, 0, 0));
  animation: cross 2s infinite;
}
@keyframes cross{
  to{
    top: 80%;
    left: 100%;
    transform: rotate(-45deg);
  }
}
\`)
`,ue=`
const chart = this.refs.vChartRef.chart
// 定义地图原点大小 同理可自定义标签等等内容
this.props.chartConfig.option.series[0].symbolSize = (val) => {
  return Math.sqrt(val[2]) / 3;
}
this.setupState.vEchartsSetOption();
let i = 0; // 当前轮播索引
const len = 3; // 轮播部分提示
(function showTips() {
  const action = (type, dataIndex) => {
    chart.dispatchAction({
      type,
      dataIndex,
      seriesIndex: 0,
    });
  }
  setInterval(() => {
    action("downplay", i);
    action("hideTip", i);
    if (i === len) i = 0;
    i++;
    action("highlight", i);
    action("showTip", i);
  }, 2000);
})()
`,_e=[{description:"获取当前组件实例",code:ae},{description:"获取全局 echarts 实例",code:se},{description:"获取组件图表集合",code:le},{description:"获取 nodeModules 实例",code:ce},{description:"获取远程 CDN 库",code:re},{description:"设置文字组件点击事件",code:de},{description:"修改图表 tooltip",code:ie},{description:"添加【轮播列表】样式",code:pe},{description:"修改【地图】圆点，新增提示自动轮播",code:ue}],v=S=>(X("data-v-78ab1c00"),S=S(),Y(),S),me={class:"func-annotate"},fe=v(()=>s("br",null,null,-1)),he={class:"func-keyword"},ge={class:"go-ml-4"},ve=v(()=>s("p",null,[n("}"),s("span",null,",")],-1)),ye={class:"go-pl-3"},be=v(()=>s("span",{class:"func-keyword"},"async function   ",-1)),xe={class:"func-keyNameWord"},Ee=v(()=>s("p",{class:"go-pl-3 func-keyNameWord"},"}",-1)),we=v(()=>s("br",null,null,-1)),ke=v(()=>s("br",null,null,-1)),Te={class:"go-flex-items-center"},Se=J({__name:"index",setup(S){const{targetData:y,chartEditStore:Oe}=te(),{DocumentTextIcon:L,ChevronDownIcon:Me,PencilIcon:P}=oe.ionicons5,$={[f.VNODE_BEFORE_MOUNT]:"渲染之前",[f.VNODE_MOUNTED]:"渲染之后"},R={[f.VNODE_BEFORE_MOUNT]:"此时组件 DOM 还未存在",[f.VNODE_MOUNTED]:"此时组件 DOM 已经存在"},b=M(!1),C=M(f.VNODE_MOUNTED);let h=M({...y.value.events.advancedEvents});const q=M(!1),F=()=>{let x="",r="",E="";return q.value=Object.entries(h.value).every(([w,k])=>{try{const m=Object.getPrototypeOf(async function(){}).constructor;return new m(k),!0}catch(m){return r=m.message,E=m.name,x=w,!1}}),{errorFn:x,message:r,name:E}},U=()=>{b.value=!1},A=()=>{if(F().errorFn){window.$message.error("事件函数错误，无法进行保存");return}Object.values(h.value).join("").trim()===""?y.value.events.advancedEvents={vnodeBeforeMount:void 0,vnodeMounted:void 0}:y.value.events.advancedEvents={...h.value},U()};return K(()=>b.value,x=>{x&&(h.value={...y.value.events.advancedEvents})}),(x,r)=>{const E=a("n-icon"),w=a("n-button"),k=a("n-code"),m=a("n-card"),i=a("n-collapse-item"),c=a("n-text"),j=a("n-space"),O=a("n-tab-pane"),B=a("n-tabs"),z=a("n-layout"),I=a("n-collapse"),V=a("n-scrollbar"),N=a("n-tag"),W=a("n-layout-sider"),H=a("n-modal");return l(),p(_,null,[t(i,{title:"高级事件配置",name:"3"},{"header-extra":e(()=>[t(w,{type:"primary",tertiary:"",size:"small",onClick:r[0]||(r[0]=Q(o=>b.value=!0,["stop"]))},{icon:e(()=>[t(E,null,{default:e(()=>[t(d(P))]),_:1})]),default:e(()=>[n(" 编辑 ")]),_:1})]),default:e(()=>[t(m,{class:"collapse-show-box"},{default:e(()=>[(l(!0),p(_,null,g(d(f),o=>(l(),p("div",{key:o},[s("p",null,[s("span",me,"// "+u($[o]),1),fe,s("span",he,"async "+u(o),1),n(" (e, components, echarts, node_modules) { ")]),s("p",ge,[t(k,{code:(d(y).events.advancedEvents||{})[o]||"",language:"typescript"},null,8,["code"])]),ve]))),128))]),_:1})]),_:1}),t(H,{class:"go-chart-data-monaco-editor",show:b.value,"onUpdate:show":r[2]||(r[2]=o=>b.value=o),"mask-closable":!1},{default:e(()=>[t(m,{bordered:!1,role:"dialog",size:"small","aria-modal":"true",style:{width:"1200px",height:"700px"}},{header:e(()=>[t(j,null,{default:e(()=>[t(c,null,{default:e(()=>[n("高级事件编辑器（配合源码使用）")]),_:1})]),_:1})]),"header-extra":e(()=>[]),action:e(()=>[t(j,{justify:"space-between"},{default:e(()=>[s("div",Te,[t(N,{bordered:!1,type:"primary"},{icon:e(()=>[t(E,{component:d(L)},null,8,["component"])]),default:e(()=>[n(" 说明 ")]),_:1}),t(c,{class:"go-ml-2",depth:"2"},{default:e(()=>[n("通过提供的参数可为图表增加定制化的tooltip、交互事件等等")]),_:1})]),t(j,null,{default:e(()=>[t(w,{size:"medium",onClick:U},{default:e(()=>[n("取消")]),_:1}),t(w,{size:"medium",type:"primary",onClick:A},{default:e(()=>[n("保存")]),_:1})]),_:1})]),_:1})]),default:e(()=>[t(z,{"has-sider":"","sider-placement":"right"},{default:e(()=>[t(z,{style:{height:"580px","padding-right":"20px"}},{default:e(()=>[t(B,{value:C.value,"onUpdate:value":r[1]||(r[1]=o=>C.value=o),type:"card","tab-style":"min-width: 100px;"},{suffix:e(()=>[t(c,{class:"tab-tip",type:"warning"},{default:e(()=>[n("提示: "+u(R[C.value]),1)]),_:1})]),default:e(()=>[(l(!0),p(_,null,g(d(f),(o,T)=>(l(),D(O,{key:T,tab:`${$[o]}-${o}`,name:o},{default:e(()=>[s("p",ye,[be,s("span",xe,u(o)+"(e, components, echarts, node_modules)  {",1)]),t(d(ee),{modelValue:d(h)[o],"onUpdate:modelValue":G=>d(h)[o]=G,height:"480px",language:"javascript"},null,8,["modelValue","onUpdate:modelValue"]),Ee]),_:2},1032,["tab","name"]))),128))]),_:1},8,["value"])]),_:1}),t(W,{"collapsed-width":14,width:340,"show-trigger":"bar","collapse-mode":"transform","content-style":"padding: 12px 12px 0px 12px;margin-left: 3px;"},{default:e(()=>[t(B,{"default-value":"1","justify-content":"space-evenly",type:"segment"},{default:e(()=>[t(O,{tab:"验证结果",name:"1",size:"small"},{default:e(()=>[t(V,{trigger:"none",style:{"max-height":"505px"}},{default:e(()=>[t(I,{class:"go-px-3","arrow-placement":"right","default-expanded-names":[1,2,3]},{default:e(()=>[(l(!0),p(_,null,g([F()],o=>(l(),p(_,{key:o},[t(i,{title:"错误函数",name:1},{default:e(()=>[t(c,{depth:"3"},{default:e(()=>[n(u(o.errorFn||"暂无"),1)]),_:2},1024)]),_:2},1024),t(i,{title:"错误信息",name:2},{default:e(()=>[t(c,{depth:"3"},{default:e(()=>[n(u(o.name||"暂无"),1)]),_:2},1024)]),_:2},1024),t(i,{title:"堆栈信息",name:3},{default:e(()=>[t(c,{depth:"3"},{default:e(()=>[n(u(o.message||"暂无"),1)]),_:2},1024)]),_:2},1024)],64))),128))]),_:1})]),_:1})]),_:1}),t(O,{tab:"变量说明",name:"2"},{default:e(()=>[t(V,{trigger:"none",style:{"max-height":"505px"}},{default:e(()=>[t(I,{class:"go-px-3","arrow-placement":"right","default-expanded-names":[1,2,3,4]},{default:e(()=>[t(i,{title:"e",name:1},{default:e(()=>[t(c,{depth:"3"},{default:e(()=>[n("触发对应生命周期事件时接收的参数")]),_:1})]),_:1}),t(i,{title:"this",name:2},{default:e(()=>[t(c,{depth:"3"},{default:e(()=>[n("图表组件实例")]),_:1}),we,(l(!0),p(_,null,g(["refs","setupState","ctx","props","..."],o=>(l(),D(N,{class:"go-m-1",key:o},{default:e(()=>[n(u(o),1)]),_:2},1024))),128))]),_:1}),t(i,{title:"components",name:3},{default:e(()=>[t(c,{depth:"3"},{default:e(()=>[n("当前大屏内所有组件的集合id 图表组件中的配置id，可以获取其他图表组件进行控制 ")]),_:1}),t(k,{code:`{
  [id]: component
}`,language:"typescript"})]),_:1}),t(i,{title:"node_modules",name:4},{default:e(()=>[t(c,{depth:"3"},{default:e(()=>[n("以下是内置在代码环境中可用的包变量")]),_:1}),ke,(l(!0),p(_,null,g(Object.keys(d(ne)||{}),o=>(l(),D(N,{class:"go-m-1",key:o},{default:e(()=>[n(u(o),1)]),_:2},1024))),128))]),_:1})]),_:1})]),_:1})]),_:1}),t(O,{tab:"介绍案例",name:"3"},{default:e(()=>[t(V,{trigger:"none",style:{"max-height":"505px"}},{default:e(()=>[t(I,{"arrow-placement":"right"},{default:e(()=>[(l(!0),p(_,null,g(d(_e),(o,T)=>(l(),D(i,{key:T,title:`案例${T+1}：${o.description}`,name:T},{default:e(()=>[t(k,{code:o.code,language:"typescript"},null,8,["code"])]),_:2},1032,["title","name"]))),128))]),_:1})]),_:1})]),_:1})]),_:1})]),_:1})]),_:1})]),_:1})]),_:1},8,["show"])],64)}}});const qe=Z(Se,[["__scopeId","data-v-78ab1c00"]]);export{qe as default};
