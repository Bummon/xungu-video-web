import{d as e}from"./index-cf10266c.js";const p=e({__name:"index",setup(o){return console.log("player"),()=>{}}});export{p as default};
