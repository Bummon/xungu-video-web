import{_ as m}from"./Drawer.vue_vue_type_script_setup_true_name_GroupDrawer_lang-f60c04c7.js";import"./index-cf10266c.js";export{m as default};
