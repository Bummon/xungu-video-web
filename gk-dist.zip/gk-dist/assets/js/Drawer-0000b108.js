import{_ as o}from"./Drawer.vue_vue_type_script_setup_true_name_Drawer_lang-d30797e6.js";import"./index-cf10266c.js";import"./area-4ddb5a07.js";import"./upload-34073856.js";export{o as default};
