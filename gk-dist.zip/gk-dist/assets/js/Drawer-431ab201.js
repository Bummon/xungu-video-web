import{_ as m}from"./Drawer.vue_vue_type_script_setup_true_name_ProfileDrawer_lang-784145db.js";import"./index-cf10266c.js";export{m as default};
