import{_ as m}from"./displayTable.vue_vue_type_script_setup_true_lang-94e15ac1.js";import"./index-cf10266c.js";export{m as default};
