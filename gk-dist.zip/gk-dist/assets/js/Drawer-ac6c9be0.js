import{_ as m}from"./Drawer.vue_vue_type_script_setup_true_name_Drawer_lang-f2fa6460.js";import"./index-cf10266c.js";export{m as default};
