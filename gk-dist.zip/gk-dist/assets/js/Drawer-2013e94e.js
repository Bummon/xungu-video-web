import{_ as m}from"./Drawer.vue_vue_type_script_setup_true_name_TemplateDrawer_lang-099f0fda.js";import"./index-cf10266c.js";export{m as default};
