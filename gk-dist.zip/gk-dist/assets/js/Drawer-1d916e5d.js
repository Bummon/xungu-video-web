import{_ as o}from"./Drawer.vue_vue_type_script_setup_true_name_RoomDrawer_lang-10f0aade.js";import"./index-cf10266c.js";import"./site-b7b4014b.js";export{o as default};
