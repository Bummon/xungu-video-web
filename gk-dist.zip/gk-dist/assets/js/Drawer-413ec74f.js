import{_ as m}from"./Drawer.vue_vue_type_script_setup_true_name_Drawer_lang-08c8c07e.js";import"./index-cf10266c.js";export{m as default};
