import{_ as o}from"./sceneDrawerDrawer.vue_vue_type_script_setup_true_name_AppDrawer_lang-4f3f340f.js";import"./scene-a4f9a167.js";import"./index-cf10266c.js";export{o as default};
